from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QPushButton, QLabel, QLineEdit
import sqlite3

# Создайте соединение с базой данных SQLite
conn = sqlite3.connect('D:/tkinter_app/my_database.db')
c = conn.cursor()

# Создайте таблицы, если они еще не существуют
c.execute('CREATE TABLE IF NOT EXISTS участки (id INTEGER PRIMARY KEY, участок TEXT)')
c.execute('CREATE TABLE IF NOT EXISTS работники (id INTEGER PRIMARY KEY, фамилия TEXT)')
c.execute('CREATE TABLE IF NOT EXISTS детали (id INTEGER PRIMARY KEY, шифр_детали TEXT, наименование_детали TEXT)')
c.execute('CREATE TABLE IF NOT EXISTS операции (id INTEGER PRIMARY KEY, деталь_id INTEGER, наименование_детали TEXT, операция TEXT, норма_времени_на_единицу REAL)')


# Создайте приложение PyQt
app = QApplication([])

# Создайте главное окно
window = QWidget()
layout = QVBoxLayout(window)

# Создайте поля для ввода данных
fields = ['участок', 'фамилия', 'шифр детали', 'наименование детали', 'операция', 'норма времени на единицу']
entries = {}

for field in fields:
    # Создайте поле для ввода для каждого поля
    label = QLabel(field)
    layout.addWidget(label)
    entry = QLineEdit()
    layout.addWidget(entry)
    entries[field] = entry

# Создайте функцию для сохранения данных
def save_data():
    # Сохраните данные в базу данных
    c.execute(f'''
        INSERT INTO операции (участок, фамилия, шифр_детали, наименование_детали, операция, норма_времени_на_единицу) VALUES 
        ('{entries["участок"].text()}', '{entries["фамилия"].text()}', '{entries["шифр детали"].text()}', '{entries["наименование детали"].text()}', '{entries["операция"].text()}', {entries["норма времени на единицу"].text()})
    ''')
    conn.commit()

# Создайте кнопку "сохранить"
button = QPushButton('сохранить')
button.clicked.connect(save_data)
layout.addWidget(button)

window.show()
app.exec_()
